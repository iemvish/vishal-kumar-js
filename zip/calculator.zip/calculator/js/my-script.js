// Write a message to the console.
console.log('hello world!');
