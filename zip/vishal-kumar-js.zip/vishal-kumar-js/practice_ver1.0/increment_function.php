<?php
$number = "001";
function increment($number)
    {
       
       echo $number;
    }
do
{
    $number = increment($number);
}
while($number ="001");

?>   
