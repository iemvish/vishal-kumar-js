<?php

class DBConn
{
    private $host;
    private $username;
    private $password;
    private $databasename;


    function __construct() {
        $this->host = "localhost";
        $this->username = "root";
        $this->password = "";
        $this->databasename = "data";
    }
    
    public function conn()
    {
        $conn = mysqli_connect($this->host,$this->username,$this->password,$this->databasename);
        return $conn;
    }
}

$dbconn = new DBConn();
$conn = $dbconn->conn();
if(mysqli_connect_error())
{
    echo mysqli_connect_error();
}
else{
    echo "connect";
}

?>