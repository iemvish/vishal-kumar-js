<?php
// write program to check number to prime or not
$a = readline("Enter number: ");
echo $a;



?>